// Catalog snapshot used by the visual prototype. Track durations are rounded down to seconds.
const songs = tracks.map(([title, art, price], index) => ({
  title, art: artRoot + art + '.png', price,
  artist: 'John doe', album: index === 0 ? '' : 'Vanity',
  duration: ['3:01', '2:05', '3:01', '4:01', '2:35', '3:11'][index]
}));
const pages = {
  'home-screen': ['Home','Summary'], 'top-songs': ['Explore','Top Songs'],
  browse: ['Explore','Browse'], trending: ['Explore','New & Hot'],
  latest: ['Browse','Latest tracks'], artist: ['Artist','John doe'],
  album: ['Album','Vanity'], playlist: ['Playlist','Listen again'],
  albums: ['Collection','Albums'], playlists: ['Collection','Playlists'],
  search: ['Search','Search tracks'], likes: ['Collection','Likes'],
  history: ['Collection','History'], later: ['Collection','Listen Later'],
  store: ['Store','Browse the store'], purchased: ['Store','Purchased']
};
const destinations = ['home-screen','browse','trending','top-songs',null,'store','purchased','later','history','likes','playlists','albums',null,null];
document.querySelectorAll('aside p').forEach((item,i)=>{
  item.classList.remove('selected');
  if (!destinations[i]) return;
  const link=document.createElement('a');
  link.href='#'+destinations[i]; link.textContent=item.textContent;
  item.replaceChildren(link);
});
const search=document.createElement('input');
search.className='search'; search.type='search'; search.placeholder='Search tracks'; search.setAttribute('aria-label','Search tracks');
document.querySelector('.top .search').replaceWith(search);
search.addEventListener('input',()=>{
  if(location.hash!=='#search') location.hash='search';
  else renderMusic('search');
});
const menuButton=document.querySelector('.hamb');
menuButton.onclick=()=>{
  const narrow=matchMedia('(max-width:760px)').matches;
  home.classList.toggle(narrow?'drawer':'compact');
  menuButton.setAttribute('aria-expanded',narrow?home.classList.contains('drawer'):!home.classList.contains('compact'));
};
function link(page,label){return '<a href="#'+page+'">'+label+'</a>'}
function trackTable(list, page){
  if (!list.length) return '<p class="empty">'+(page==='search'?'No tracks match your search.':'No tracks here yet.')+'</p>';
  const showAlbum=page!=='album';
  const rows=list.map((song,i)=>'<tr><td class="number">'+String(i+1).padStart(2,'0')+'</td><td><div class="track-title"><img src="'+song.art+'" alt=""><span>'+song.title+'<small>'+song.artist+'</small></span></div></td><td class="by">'+link('artist',song.artist)+'</td>'+
    (showAlbum?'<td class="release">'+(song.album?link('album',song.album):'—')+'</td>':'')+
    '<td class="cost"><span>GH₵ '+song.price+'</span></td><td class="length">'+song.duration+'</td><td class="more"><details><summary aria-label="Actions for '+song.title+'">•••</summary><div>Play track<br>Like<br>Download</div></details></td></tr>').join('');
  return '<table aria-label="Songs"><thead><tr><th class="number">#</th><th>Title</th><th class="by">Artist</th>'+(showAlbum?'<th class="release">Album</th>':'')+'<th class="cost">Price</th><th class="length">Time</th><th class="more">More</th></tr></thead><tbody>'+rows+'</tbody></table>';
}
// Sample profiles illustrate the layout alongside the catalog's linked artist.
function artistGrid(){
  const artists=[
    ['Esi Vale',4],['Kojo Lane',2],['Ama Sol',3],
    ['Nii Grey',6],['Adwoa Blu',2]
  ];
  const samples=artists.map(([name,albums],i)=>{
    const position=(i%3)*50+'% '+Math.floor(i/3)*100+'%';
    return `<li><span class="artist-portrait" style="background-position:${position}"></span><strong>${name}</strong><small>${albums} albums</small></li>`;
  });
  samples.push('<li><a href="#artist"><img class="artist-portrait" src="assets/assets/images/avatar.png" alt=""><strong>John doe</strong><small>1 album</small></a></li>');
  return '<ul class="artist-grid">'+samples.join('')+'</ul>';
}
function covers(items){
  return '<div class="covers">'+items.map(([song,page,label])=>'<a href="#'+page+'"><img src="'+song.art+'" alt=""><strong>'+label+'</strong><small>'+song.artist+'</small></a>').join('')+'</div>';
}
function section(title,body,more=''){return '<section class="music-section"><header><h2>'+title+'</h2>'+more+'</header>'+body+'</section>'}
function renderMusic(requested){
  if(['home-screen','feed'].includes(requested)){renderHome(requested);return}
  const page=Object.hasOwn(pages,requested)?requested:'top-songs';
  const [group,title]=pages[page];
  const chart=['top-songs','home-screen','trending'].includes(page);
  const heroArt=page==='album'?songs[1]:page==='playlist'?songs[4]:null;
  let body='';
  if(chart){
    const nav=page==='home-screen'?'<span>Summary</span> · Feed':link('trending','New & Hot')+' / '+link('top-songs','Top 50');
    body='<div class="list-tools"><span>'+nav+'</span><span>'+ (page==='home-screen'?'This week · This month · This year':page==='top-songs'?'This week　 ·　 All genres':'All genres')+'</span></div>'+trackTable(songs,page);
    if(page==='home-screen')body+=section('New Albums',covers([[songs[1],'album','Vanity']]));
  }else if(page==='browse'){
    body='<nav class="subnav">'+link('latest','Latest tracks')+link('artist','Artists')+link('playlists','Playlists')+link('albums','Albums')+'</nav>'+
      section('This week’s top songs',trackTable(songs.slice(0,4),page),link('top-songs','View chart ↗'))+
      section('New & Hot',covers([[songs[0],'trending','Mani'],[songs[1],'trending','Vanity'],[songs[4],'trending',songs[4].title]]))+
      section('Top Artists',artistGrid());
  }else if(page==='albums'||page==='playlists'){
    body=covers(page==='albums'?[[songs[1],'album','Vanity']]:[[songs[4],'playlist','Listen again']]);
  }else{
    let list=songs;
    if(page==='album')list=songs.filter(song=>song.album);
    if(page==='playlist')list=[songs[4],songs[1],songs[0]];
    if(page==='latest')list=[...songs].reverse();
    if(['later','history','likes','purchased'].includes(page))list=[];
    if(page==='search')list=songs.filter(song=>(song.title+' '+song.artist+' '+song.album).toLowerCase().includes(search.value.toLowerCase().trim()));
    body=section(page==='artist'?'Top tracks':page==='album'||page==='playlist'?'Tracklist':'Tracks',trackTable(list,page));
    if(page==='artist')body+=section('Albums',covers([[songs[1],'album','Vanity']]));
  }
  const stack=chart?'<div class="sleeves" aria-hidden="true">'+[songs[4],songs[1],songs[0]].map(song=>'<img src="'+song.art+'" alt="">').join('')+'</div>':'';
  document.querySelector('#music-page').innerHTML='<header class="music-hero '+(chart?'chart-hero':'')+'">'+(heroArt?'<img class="cover-lead" src="'+heroArt.art+'" alt="">':'')+
    '<div><div class="crumb">'+group+'</div><h1>'+title+'</h1>'+(heroArt?'<p>'+link('artist','John doe')+'</p>':'')+'</div>'+stack+'</header>'+body;
  document.querySelectorAll('aside a').forEach(a=>a.parentElement.classList.toggle('selected',a.hash==='#'+page));
  home.classList.remove('drawer');
}
render();
